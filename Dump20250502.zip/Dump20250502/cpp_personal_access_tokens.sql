-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cpp
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (2,'App\\Models\\User',2,'google-login','a8bf98b58cf1aac629e6f02626c71d51e392945e352f084cdec2b26040a357cb','[\"*\"]','2025-05-01 02:27:54','2025-05-01 02:27:53','2025-05-01 02:27:54'),(13,'App\\Models\\User',2,'google-login','79ae3cc4497a456a6db6c29d81c239113357acc68e94cffb8989f46379e7d897','[\"*\"]','2025-05-01 05:17:47','2025-05-01 05:00:11','2025-05-01 05:17:47'),(14,'App\\Models\\User',2,'google-login','b30e2718a483cf40461750a73489239940ac8b6da85f0bf3e9d791f37c7f8933','[\"*\"]','2025-05-01 12:36:24','2025-05-01 05:18:34','2025-05-01 12:36:24'),(15,'App\\Models\\User',2,'google-login','3b7f5715fc210a863c39708cce907fd4e3045b4caaee7832ca117169abed21b9','[\"*\"]','2025-05-02 00:35:30','2025-05-01 17:46:55','2025-05-02 00:35:30'),(17,'App\\Models\\User',1,'google-login','0d0c2e07d6e1ecf115e4512f51763bfbc04fb0f4059f9607212b4d0bddee8095','[\"*\"]','2025-05-02 01:13:53','2025-05-02 00:47:08','2025-05-02 01:13:53'),(18,'App\\Models\\User',2,'google-login','0fc34e1822d186a27dd3bf54a610b13036eec95b7acdfe37e81f86a89147250a','[\"*\"]','2025-05-02 02:06:20','2025-05-02 01:13:33','2025-05-02 02:06:20'),(19,'App\\Models\\User',1,'google-login','90a16ab5749f9bfda4202ad9563434f0f1ca6f017269d5a0d1c0d074738afe68','[\"*\"]','2025-05-02 03:34:28','2025-05-02 02:06:46','2025-05-02 03:34:28');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-02 17:42:40
