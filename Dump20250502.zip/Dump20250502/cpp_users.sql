-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cpp
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `google_id` text DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `avatar` text DEFAULT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `active` smallint(6) NOT NULL DEFAULT 0,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fcm_token` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'dennis wijaya','dens6942@gmail.com','107616668209723282938','user','https://lh3.googleusercontent.com/a/ACg8ocIA0Ul5nLfbUDAoRZ5q21Tlu3FS43Dppo0ztgJOhVOcZL1ZqlQn=s96-c','hubby',1,NULL,'$2y$10$CyxUr.31///SuZKNxr08wudvmqNEs2npvpHLdi9qLPoLEXrds1L0O',NULL,'2025-05-01 01:31:47','2025-05-02 02:08:31','fqf3H6awguVBe0tdgiBJQt:APA91bE8dLJrbq1E4Ypk0bD9_aGHANP4yfUBwj8lWnC2YFNGM2NhAOVOYzb2eRZRsSmjEhlkqMLDhIy99JO1D9FHQDq9mcDc4teS989-IIxxAiM02rVALrU'),(2,'dennis wijaya','martin.dennis.wijaya@gmail.com','117831530217928488311','user','https://lh3.googleusercontent.com/a/ACg8ocJtI5U-OnHTFxxXFSlRTXjZZUSCkNwA9vc1_b1GaqjZ8ROPFA=s96-c','gggg',1,NULL,'$2y$10$QI0PGhC/P52JsFcXTWlgCuxQj8tzafxehM25o4nJfsk/eynUpul5u',NULL,'2025-05-01 02:27:53','2025-05-02 01:13:36','fqf3H6awguVBe0tdgiBJQt:APA91bE8dLJrbq1E4Ypk0bD9_aGHANP4yfUBwj8lWnC2YFNGM2NhAOVOYzb2eRZRsSmjEhlkqMLDhIy99JO1D9FHQDq9mcDc4teS989-IIxxAiM02rVALrU');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-02 17:42:40
