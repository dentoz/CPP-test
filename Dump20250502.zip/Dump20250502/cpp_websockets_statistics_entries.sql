-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cpp
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `websockets_statistics_entries`
--

DROP TABLE IF EXISTS `websockets_statistics_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `websockets_statistics_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` varchar(255) NOT NULL,
  `peak_connections_count` int(11) NOT NULL,
  `websocket_messages_count` int(11) NOT NULL,
  `api_messages_count` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `websockets_statistics_entries`
--

LOCK TABLES `websockets_statistics_entries` WRITE;
/*!40000 ALTER TABLE `websockets_statistics_entries` DISABLE KEYS */;
INSERT INTO `websockets_statistics_entries` VALUES (1,'1984939',2,31,0,'2025-05-01 21:47:52','2025-05-01 21:47:52'),(2,'1984939',2,3,0,'2025-05-01 21:48:52','2025-05-01 21:48:52'),(3,'1984939',2,5,0,'2025-05-01 21:49:52','2025-05-01 21:49:52'),(4,'1984939',2,12,0,'2025-05-01 21:51:08','2025-05-01 21:51:08'),(5,'1984939',2,4,0,'2025-05-01 21:52:08','2025-05-01 21:52:08'),(6,'1984939',2,4,0,'2025-05-01 21:53:08','2025-05-01 21:53:08'),(7,'1984939',2,4,0,'2025-05-01 21:54:08','2025-05-01 21:54:08'),(8,'1984939',2,2,0,'2025-05-01 21:55:08','2025-05-01 21:55:08'),(9,'1984939',2,4,0,'2025-05-01 21:56:08','2025-05-01 21:56:08'),(10,'1984939',2,4,0,'2025-05-01 21:57:08','2025-05-01 21:57:08'),(11,'1984939',2,4,0,'2025-05-01 21:58:08','2025-05-01 21:58:08'),(12,'1984939',2,6,0,'2025-05-01 21:59:08','2025-05-01 21:59:08'),(13,'1984939',2,3,0,'2025-05-01 22:00:08','2025-05-01 22:00:08'),(14,'1984939',2,4,0,'2025-05-01 22:01:08','2025-05-01 22:01:08'),(15,'1984939',2,4,0,'2025-05-01 22:02:08','2025-05-01 22:02:08'),(16,'1984939',2,4,0,'2025-05-01 22:03:08','2025-05-01 22:03:08'),(17,'1984939',2,2,0,'2025-05-01 22:04:08','2025-05-01 22:04:08'),(18,'1984939',2,4,0,'2025-05-01 22:05:08','2025-05-01 22:05:08');
/*!40000 ALTER TABLE `websockets_statistics_entries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-02 17:42:39
